import Image from 'next/image'
import type { Author } from '@/lib/blog'

interface AuthorBlockProps {
  author: Author
}

export default function AuthorBlock({ author }: AuthorBlockProps) {
  return (
    <div
      className="mt-16 pt-10 flex flex-col sm:flex-row gap-6 items-start"
      style={{ borderTop: '1px solid var(--color-linen)' }}
    >
      <div className="relative shrink-0 w-16 h-16 rounded-full overflow-hidden">
        <Image
          src={author.avatar}
          alt={author.name}
          fill
          className="object-cover"
          sizes="64px"
        />
      </div>
      <div>
        <p
          className="font-body font-semibold m-0 mb-0.5"
          style={{ fontSize: '0.9rem', color: 'var(--color-ink)' }}
        >
          {author.name}
        </p>
        <p
          className="font-body m-0 mb-2"
          style={{ fontSize: '0.78rem', color: 'var(--color-red)', letterSpacing: '0.05em' }}
        >
          {author.role}
        </p>
        <p
          className="font-body m-0 mb-3"
          style={{ fontSize: '0.875rem', color: 'rgba(26,26,26,0.65)', lineHeight: 1.7 }}
        >
          {author.bio}
        </p>
        <a
          href={author.linkedin}
          target="_blank"
          rel="noopener noreferrer"
          className="font-body inline-flex items-center gap-1.5 text-xs tracking-[0.08em] uppercase font-medium transition-opacity hover:opacity-70"
          style={{ color: 'var(--color-ink)' }}
        >
          LinkedIn
          <svg width="10" height="10" viewBox="0 0 10 10" fill="none" aria-hidden="true">
            <path d="M1 9L9 1M9 1H3M9 1V7" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </a>
      </div>
    </div>
  )
}