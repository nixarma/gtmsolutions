'use client'

import { useEffect } from 'react'

export default function MidCTA() {
  useEffect(() => {
    // Load Cal.com embed script if not already present
    if (typeof window !== 'undefined' && !(window as any).Cal) {
      const script = document.createElement('script')
      script.src = 'https://app.cal.com/embed/embed.js'
      script.async = true
      document.head.appendChild(script)

      script.onload = () => {
        ;(window as any).Cal('init', { origin: 'https://cal.com' })
      }
    }
  }, [])

  function openCal() {
    if (typeof window !== 'undefined' && (window as any).Cal) {
      ;(window as any).Cal('ui', {
        styles: { branding: { brandColor: '#99332F' } },
        hideEventTypeDetails: false,
      })
      ;(window as any).Cal('modal', {
        calLink: 'nikhilsarma/intros',
      })
    }
  }

  return (
    <div
      className="my-12 p-8 rounded-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6"
      style={{ background: 'var(--color-ink)' }}
    >
      <div>
        <p
          className="font-display italic font-medium m-0 mb-1"
          style={{
            fontSize: 'clamp(1.1rem, 1.8vw, 1.35rem)',
            color: '#fff',
            lineHeight: 1.3,
          }}
        >
          Working through something like this?
        </p>
        <p
          className="font-body m-0"
          style={{ fontSize: '0.875rem', color: 'rgba(255,255,255,0.6)' }}
        >
          A 30-minute conversation is usually enough to find the gap.
        </p>
      </div>
      <button
        onClick={openCal}
        className="shrink-0 font-body text-xs tracking-[0.1em] uppercase font-medium px-7 py-3 rounded-sm transition-opacity hover:opacity-90"
        style={{ background: 'var(--color-red)', color: '#fff' }}
      >
        Book a call
      </button>
    </div>
  )
}