interface PullQuoteProps {
    children: React.ReactNode
    attr?: string
  }
  
  export default function PullQuote({ children, attr }: PullQuoteProps) {
    return (
      <blockquote
        className="my-10 mx-0 py-8 px-8 relative"
        style={{
          borderLeft: '3px solid var(--color-red)',
          background: 'var(--color-red-light)',
        }}
      >
        <p
          className="font-display italic font-medium leading-snug m-0"
          style={{
            fontSize: 'clamp(1.25rem, 2vw, 1.5rem)',
            color: 'var(--color-ink)',
          }}
        >
          {children}
        </p>
        {attr && (
          <cite
            className="block mt-4 not-italic font-body"
            style={{
              fontSize: '0.75rem',
              letterSpacing: '0.1em',
              textTransform: 'uppercase',
              color: 'var(--color-red)',
            }}
          >
            {attr}
          </cite>
        )}
      </blockquote>
    )
  }