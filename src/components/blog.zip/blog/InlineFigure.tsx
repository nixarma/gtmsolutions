import Image from 'next/image'

interface InlineFigureProps {
  src: string
  alt: string
  label?: string
  caption?: string
}

export default function InlineFigure({ src, alt, label, caption }: InlineFigureProps) {
  return (
    <figure className="my-10 mx-0">
      <div
        className="relative w-full overflow-hidden rounded-sm"
        style={{ aspectRatio: '16/9' }}
      >
        <Image
          src={src}
          alt={alt}
          fill
          className="object-cover"
          sizes="(max-width: 768px) 100vw, 720px"
        />
      </div>
      {(label || caption) && (
        <figcaption
          className="mt-3 font-body"
          style={{
            fontSize: '0.8rem',
            color: 'rgba(26,26,26,0.55)',
            lineHeight: 1.6,
          }}
        >
          {label && (
            <span
              className="font-medium mr-2"
              style={{ color: 'var(--color-red)' }}
            >
              {label}.
            </span>
          )}
          {caption}
        </figcaption>
      )}
    </figure>
  )
}