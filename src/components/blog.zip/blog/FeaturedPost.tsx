import Link from 'next/link'
import type { Post } from '@/lib/blog'
import CoverImage, { CoverFallback } from './CoverImage'

interface FeaturedPostProps {
  post: Post
}

export default function FeaturedPost({ post }: FeaturedPostProps) {
  return (
    <Link
      href={`/blog/${post.slug}`}
      className="group block hover:no-underline mb-16"
      style={{ textDecoration: 'none' }}
    >
      <div className="grid grid-cols-1 lg:grid-cols-[1.1fr_0.9fr] gap-8 lg:gap-12 items-center">

        {/* Cover */}
        <div className="overflow-hidden rounded-sm transition-transform duration-500 group-hover:scale-[1.01]">
          {post.cover ? (
            <CoverImage cover={post.cover} variant="featured" priority />
          ) : (
            <CoverFallback variant="featured" />
          )}
        </div>

        {/* Content */}
        <div className="flex flex-col">
          {/* Featured label + category */}
          <div className="flex items-center gap-3 mb-5">
            <span
              className="font-body font-medium text-[0.65rem] tracking-[0.18em] uppercase px-2.5 py-0.5 rounded-full"
              style={{ background: 'var(--color-ink)', color: '#fff' }}
            >
              Featured
            </span>
            <span
              className="font-body font-medium text-[0.65rem] tracking-[0.14em] uppercase px-2.5 py-0.5 rounded-full"
              style={{ background: 'var(--color-red-light)', color: 'var(--color-red)' }}
            >
              {post.category}
            </span>
          </div>

          {/* Title */}
          <h2
            className="font-display italic font-medium m-0 mb-4"
            style={{
              fontSize: 'clamp(1.6rem, 2.8vw, 2.4rem)',
              lineHeight: 1.12,
              color: 'var(--color-ink)',
            }}
          >
            {post.title}
          </h2>

          {/* Excerpt */}
          <p
            className="font-body m-0 mb-6"
            style={{
              fontSize: '1rem',
              lineHeight: 1.8,
              color: 'rgba(26,26,26,0.65)',
              maxWidth: 480,
            }}
          >
            {post.excerpt}
          </p>

          {/* Meta */}
          <div
            className="flex items-center gap-4 mb-6 font-body"
            style={{ fontSize: '0.78rem', color: 'rgba(26,26,26,0.45)' }}
          >
            <span>{post.date}</span>
            <span
              className="w-1 h-1 rounded-full"
              style={{ background: 'rgba(26,26,26,0.25)' }}
              aria-hidden="true"
            />
            <span>{post.readTime}</span>
          </div>

          {/* Tags */}
          {post.tags?.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mb-7">
              {post.tags.map((tag) => (
                <span
                  key={tag}
                  className="font-body text-[0.65rem] tracking-[0.1em] uppercase px-2 py-0.5 rounded-full"
                  style={{
                    background: 'var(--color-sage-light)',
                    color: 'var(--color-sage)',
                  }}
                >
                  {tag}
                </span>
              ))}
            </div>
          )}

          {/* Read link */}
          <span
            className="font-body inline-flex items-center gap-2 text-xs tracking-[0.1em] uppercase font-medium transition-opacity group-hover:opacity-60"
            style={{ color: 'var(--color-ink)' }}
          >
            Read article
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true">
              <path d="M1 11L11 1M11 1H3M11 1V9" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </span>
        </div>
      </div>

      {/* Divider below featured */}
      <div
        className="mt-12"
        style={{ height: '1px', background: 'var(--color-linen)' }}
        aria-hidden="true"
      />
    </Link>
  )
}