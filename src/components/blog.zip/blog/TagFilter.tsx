'use client'

import { useQueryState } from 'nuqs'
import { ALL_TAGS, type Tag } from '@/lib/tags'

export default function TagFilter() {
  const [activeTag, setActiveTag] = useQueryState('tag', {
    defaultValue: '',
    shallow: false,
  })

  function handleTag(tag: Tag) {
    setActiveTag(activeTag === tag ? '' : tag)
  }

  return (
    <div className="flex flex-wrap items-center gap-2 mb-10">
      {/* All button */}
      <button
        onClick={() => setActiveTag('')}
        className="font-body text-[0.72rem] tracking-[0.1em] uppercase font-medium px-4 py-1.5 rounded-full transition-all"
        style={{
          background: !activeTag ? 'var(--color-ink)' : 'transparent',
          color: !activeTag ? '#fff' : 'rgba(26,26,26,0.55)',
          border: !activeTag ? '1px solid var(--color-ink)' : '1px solid rgba(26,26,26,0.2)',
        }}
      >
        All
      </button>

      {ALL_TAGS.map((tag) => {
        const isActive = activeTag === tag
        return (
          <button
            key={tag}
            onClick={() => handleTag(tag)}
            className="font-body text-[0.72rem] tracking-[0.1em] uppercase font-medium px-4 py-1.5 rounded-full transition-all"
            style={{
              background: isActive ? 'var(--color-sage)' : 'transparent',
              color: isActive ? '#fff' : 'rgba(26,26,26,0.55)',
              border: isActive ? '1px solid var(--color-sage)' : '1px solid rgba(26,26,26,0.2)',
            }}
          >
            {tag}
          </button>
        )
      })}
    </div>
  )
}