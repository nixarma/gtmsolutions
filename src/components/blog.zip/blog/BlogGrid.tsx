'use client'

import { useQueryState } from 'nuqs'
import type { Post } from '@/lib/blog'
import type { Tag } from '@/lib/tags'
import PostCard from './PostCard'

interface BlogGridProps {
  posts: Post[]
}

export default function BlogGrid({ posts }: BlogGridProps) {
  const [activeTag] = useQueryState('tag', { defaultValue: '' })

  const filtered = activeTag
    ? posts.filter((p) => p.tags?.includes(activeTag as Tag))
    : posts

  if (filtered.length === 0) {
    return (
      <div className="py-16 text-center">
        <p
          className="font-display italic"
          style={{ fontSize: '1.1rem', color: 'rgba(26,26,26,0.4)' }}
        >
          No posts tagged with &ldquo;{activeTag}&rdquo; yet.
        </p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12">
      {filtered.map((post) => (
        <PostCard key={post.slug} post={post} />
      ))}
    </div>
  )
}