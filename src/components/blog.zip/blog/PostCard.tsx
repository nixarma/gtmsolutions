import Link from 'next/link'
import type { Post } from '@/lib/blog'
import CoverImage, { CoverFallback } from './CoverImage'

interface PostCardProps {
  post: Post
}

export default function PostCard({ post }: PostCardProps) {
  return (
    <Link
      href={`/blog/${post.slug}`}
      className="group flex flex-col gap-0 hover:no-underline"
      style={{ textDecoration: 'none' }}
    >
      {/* Cover */}
      <div className="overflow-hidden rounded-sm mb-5 transition-transform duration-500 group-hover:scale-[1.01]">
        {post.cover ? (
          <CoverImage cover={post.cover} variant="card" />
        ) : (
          <CoverFallback variant="card" />
        )}
      </div>

      {/* Meta row */}
      <div className="flex items-center gap-3 mb-3">
        <span
          className="font-body font-medium text-[0.68rem] tracking-[0.14em] uppercase px-2.5 py-0.5 rounded-full"
          style={{
            background: 'var(--color-red-light)',
            color: 'var(--color-red)',
          }}
        >
          {post.category}
        </span>
        <span
          className="font-body"
          style={{ fontSize: '0.75rem', color: 'rgba(26,26,26,0.45)' }}
        >
          {post.date}
        </span>
        <span
          className="font-body"
          style={{ fontSize: '0.75rem', color: 'rgba(26,26,26,0.45)' }}
        >
          {post.readTime}
        </span>
      </div>

      {/* Title */}
      <h2
        className="font-display italic font-medium m-0 mb-3 transition-colors"
        style={{
          fontSize: 'clamp(1.2rem, 1.8vw, 1.45rem)',
          lineHeight: 1.2,
          color: 'var(--color-ink)',
        }}
      >
        {post.title}
      </h2>

      {/* Excerpt */}
      <p
        className="font-body m-0 mb-4"
        style={{
          fontSize: '0.9rem',
          lineHeight: 1.75,
          color: 'rgba(26,26,26,0.65)',
        }}
      >
        {post.excerpt}
      </p>

      {/* Tags */}
      {post.tags?.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mt-auto">
          {post.tags.map((tag) => (
            <span
              key={tag}
              className="font-body text-[0.65rem] tracking-[0.1em] uppercase px-2 py-0.5 rounded-full"
              style={{
                background: 'var(--color-sage-light)',
                color: 'var(--color-sage)',
              }}
            >
              {tag}
            </span>
          ))}
        </div>
      )}
    </Link>
  )
}