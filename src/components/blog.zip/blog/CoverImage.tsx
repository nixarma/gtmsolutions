import Image from 'next/image'
import type { Cover } from '@/lib/blog'

const BG_MAP: Record<string, string> = {
  linen: 'var(--color-linen)',
  'sage-light': 'var(--color-sage-light)',
  'red-light': 'var(--color-red-light)',
  white: '#ffffff',
}

interface CoverImageProps {
  cover: Cover
  priority?: boolean
  /** 'hero' = full-bleed tall, 'card' = card thumbnail, 'featured' = wide short */
  variant?: 'hero' | 'card' | 'featured'
}

export default function CoverImage({
  cover,
  priority = false,
  variant = 'hero',
}: CoverImageProps) {
  const aspectMap = {
    hero: '21/9',
    card: '4/3',
    featured: '16/7',
  }

  if (cover.kind === 'photo') {
    return (
      <div
        className="relative w-full overflow-hidden rounded-sm"
        style={{ aspectRatio: aspectMap[variant] }}
      >
        <Image
          src={cover.src}
          alt={cover.alt}
          fill
          priority={priority}
          className="object-cover"
          sizes={
            variant === 'card'
              ? '(max-width: 768px) 100vw, 400px'
              : '(max-width: 768px) 100vw, 1200px'
          }
        />
      </div>
    )
  }

  // Editorial cover — typographic tile
  const bg = BG_MAP[cover.bg] ?? BG_MAP['linen']
  const isLight = cover.bg === 'white' || cover.bg === 'linen' || cover.bg === 'sage-light'

  return (
    <div
      className="relative w-full overflow-hidden rounded-sm flex flex-col justify-between p-6 sm:p-8"
      style={{
        aspectRatio: aspectMap[variant],
        background: bg,
      }}
    >
      {/* Issue number */}
      <span
        className="font-body font-medium"
        style={{
          fontSize: '0.7rem',
          letterSpacing: '0.2em',
          textTransform: 'uppercase',
          color: isLight ? 'rgba(26,26,26,0.4)' : 'rgba(255,255,255,0.4)',
        }}
      >
        {cover.num}
      </span>

      {/* Phrase */}
      <p
        className="font-display italic font-medium m-0"
        style={{
          fontSize: variant === 'card' ? 'clamp(1.4rem, 3vw, 1.8rem)' : 'clamp(2rem, 4vw, 3rem)',
          lineHeight: 1.15,
          color: isLight ? 'var(--color-ink)' : '#fff',
          whiteSpace: 'pre-line',
        }}
      >
        {cover.phrase}
      </p>
    </div>
  )
}

// Fallback cover for posts with no cover defined
export function CoverFallback({ variant = 'hero' }: { variant?: 'hero' | 'card' | 'featured' }) {
  const aspectMap = {
    hero: '21/9',
    card: '4/3',
    featured: '16/7',
  }

  return (
    <div
      className="relative w-full overflow-hidden rounded-sm flex items-center justify-center"
      style={{
        aspectRatio: aspectMap[variant],
        background: 'var(--color-linen)',
      }}
    >
      <span
        className="font-display italic"
        style={{ fontSize: '1rem', color: 'rgba(26,26,26,0.3)' }}
      >
        GTM Solutions
      </span>
    </div>
  )
}